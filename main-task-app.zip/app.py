import streamlit as st

st.set_page_config(page_title="Alaska SnowBot", layout="wide")

from main import process_chat  # replace with actual import
st.title("❄️ Alaska Department of Snow Chatbot")

if "history" not in st.session_state:
    st.session_state["history"] = []

user_input = st.chat_input("Ask about the Alaska Department of Snow...")
if user_input:
    response, updated_history = process_chat(user_input, st.session_state["history"])
    st.session_state["history"] = updated_history

for msg in st.session_state["history"]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
