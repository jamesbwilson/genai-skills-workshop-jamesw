from google import genai
from google.genai import types
import base64
import pandas as pd
from vertexai.preview.evaluation import EvalTask, MetricPromptTemplateExamples
import vertexai
from vertexai.generative_models import (
    FunctionDeclaration,
    GenerationConfig,
    GenerationResponse,
    GenerativeModel,
    Part,
    Tool
)
import requests

def generate_contents(chat_history):
    """
    Converts a structured chat history and system instruction into Gemini-compatible contents.

    Args:
        chat_history (list): A list of dicts with keys 'role' and 'content'

    Returns:
        list[types.Content]: Gemini-compatible message sequence.
    """
    contents = [
        types.Content(
            role=entry["role"],
            parts=[types.Part.from_text(text=entry["content"])]
        ) for entry in chat_history
    ]

    return contents




ALASKA_CITIES = {
    "Anchorage": (61.2175, -149.8584),
    "Fairbanks": (64.8378, -147.7164),
    "Juneau": (58.3019, -134.4197),
    "Nome": (64.5011, -165.4064),
    "Barrow": (71.2906, -156.7887),
    "Kodiak": (57.79, -152.4072),
    "Sitka": (57.0531, -135.3300)
}

def get_weather_for_alaska_city(city_name: str) -> str:
    """
    Given a city name in Alaska, return a forecast summary from weather.gov.
    """
    coords = ALASKA_CITIES.get(city_name)
    if not coords:
        print(f"❌ City '{city_name}' not recognized. Defaulting to Anchorage")
        coords=(61.2175, -149.8584)


    lat, lon = coords
    point_url = f"https://api.weather.gov/points/{lat},{lon}"

    try:
        point_resp = requests.get(point_url, timeout=10)
        point_resp.raise_for_status()
        forecast_url = point_resp.json()["properties"]["forecast"]
    except Exception as e:
        return f"⚠️ Failed to retrieve forecast URL: {e}"

    try:
        forecast_resp = requests.get(forecast_url, timeout=10)
        forecast_resp.raise_for_status()
        periods = forecast_resp.json()["properties"]["periods"]
        today = periods[0]
        return f"📍 {city_name}: {today['name']} - {today['shortForecast']}, {today['temperature']}°{today['temperatureUnit']}"
    except Exception as e:
        return f"⚠️ Failed to retrieve weather data: {e}"



weather_function = types.FunctionDeclaration(
    name="get_weather_for_alaska_city",
    description="Get the current forecast for an Alaska city using weather.gov",
    parameters={
        "type": "object",
        "properties": {
            "city_name": {
                "type": "string",
                "description": "The name of an Alaska city like 'Anchorage', 'Nome', or 'Juneau'"
            }
        }
    }
)

weather_tool = types.Tool(function_declarations=[weather_function])
datastore_tool = types.Tool(retrieval=types.Retrieval(vertex_ai_search=types.VertexAISearch(datastore="projects/qwiklabs-gcp-02-c706fd6470f9/locations/us/collections/default_collection/dataStores/ads-final_1747146243164"))),
  
def generate(content, instructions,temp=0,tool=datastore_tool[0]):
  client = genai.Client(
      vertexai=True,
      project="qwiklabs-gcp-02-c706fd6470f9",
      location="us-central1",
  )

  model = "gemini-2.0-flash-001" #Use flash because its fast
  contents = content
  generate_content_config = types.GenerateContentConfig(
    temperature = temp, #0 Temp is better for classification
    top_p = 1,
    seed = 0,
    max_output_tokens = 8192,
    safety_settings = [types.SafetySetting(
      category="HARM_CATEGORY_HATE_SPEECH",
      threshold="BLOCK_LOW_AND_ABOVE"
    ),types.SafetySetting(
      category="HARM_CATEGORY_DANGEROUS_CONTENT",
      threshold="BLOCK_LOW_AND_ABOVE"
    ),types.SafetySetting(
      category="HARM_CATEGORY_SEXUALLY_EXPLICIT",
      threshold="BLOCK_LOW_AND_ABOVE"
    ),types.SafetySetting(
      category="HARM_CATEGORY_HARASSMENT",
      threshold="BLOCK_LOW_AND_ABOVE"
    )],
    system_instruction=[types.Part.from_text(text=instructions)],
    tools=[tool]
  )
  response = client.models.generate_content(
    model = model,
    contents = contents,
    config = generate_content_config,
    )
  return response

def handle_function_calls(response):
    if response.function_calls:
        call = response.function_calls[0]
        return call.name, call.args
    return None, None

def validate_input(user_input: str) -> bool:
    instruction = (
        "You are a validation assistant. Your job is to verify whether a user input is safe, on-topic, and appropriate for a general assistant that may access tools or APIs such as weather lookups or technical support.\n"
        "Reply with 'VALID' if the input is acceptable for such a system, or 'INVALID' if it is inappropriate, unsafe, or out of scope."
    )
    contents = generate_contents([{"role": "user", "content": user_input}])
    reply = generate(contents, instruction)
    return "INVALID" not in reply.text

def validate_output(user_input: str, model_response: str) -> bool:
    instruction = (
        "You are an output reviewer for a tool-assisted assistant. Evaluate whether the AI response is relevant, appropriate, and safe.\n"
        "Reply with 'VALID' if the response is clear and suitable; reply 'INVALID' if the response is harmful, misleading, or off-topic. DO NOT REPLY WITH ANYTHING ELSE"
    )
    contents = generate_contents([{"role": "user", "content": model_response}])
    reply = generate(contents, instruction).text
    return "INVALID" not in reply

def process_chat(user_input, history=None):
    if not validate_input(user_input):
        return "I'm sorry, I don't understand. Please ask a specific and relevant question.", []
    if history is None:
        history = []
    history.append({"role": "user", "content": user_input})
    contents = generate_contents(history)

    # First pass with weather tool
    response = generate(contents, "You are a helpful assistant that may call functions like weather tools if needed.", temp=0, tool=weather_tool)
    name, args = handle_function_calls(response)
    if name == "get_weather_for_alaska_city":
        # Weather tool was triggered; return that result
        weather_details = get_weather_for_alaska_city(args['city_name'])
        weather_contents = generate_contents([{"role": "user", "content": str(weather_details)}])
        weather_response=generate(weather_contents,"You are a helpful weather bot, please provide a summary of this weather details")
        if not validate_output(user_input, str(weather_response)):
            return "Sorry, the response could not be validated.", []
        history.append({"role": "model", "content": str(weather_response)})
        return str(weather_response), history
    else:
        # No weather function needed, fall back to default RAG tool
        main_response = generate(contents, main_instructions, temp=0.4)
        main_response = main_response.text
        if not validate_output(user_input, str(main_response)):
            return "Sorry, that answer could not be validated. Try asking in a different way.", []
        history.append({"role": "model", "content": str(main_response)})
        return str(main_response), history



