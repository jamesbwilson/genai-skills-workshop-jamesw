gcloud builds submit --tag gcr.io/qwiklabs-gcp-02-c706fd6470f9/snowbot
gcloud run deploy snowbot \
  --image gcr.io/qwiklabs-gcp-02-c706fd6470f9/snowbot \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated

